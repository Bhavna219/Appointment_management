﻿using System.ComponentModel.DataAnnotations;

namespace User_Management.Models.ViewModel
{
    public class LoginSignUpViewModel
    {






        public string Username { get; set; }
        public string Password { get; set; }


        [Display(Name = "Remember")]
        public bool IsRemember { get; set; }
    }
}
