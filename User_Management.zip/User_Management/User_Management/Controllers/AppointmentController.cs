﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Exchange.WebServices.Data;
using User_Management.Data;

namespace User_Management.Controllers
{
    public class AppointmentController : Controller
    {
        private readonly ApplicationContext context;

        public AppointmentController(ApplicationContext context)
        {
            this.context = context;
        }
        public IActionResult Index()
        {
            var result = context.Appointments.ToList();
            return View(result);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
/*
        [HttpPost]
        public IActionResult Create(Appointment model)
        {
            if (ModelState.IsValid)
            {
                var emp = new Appointments()
                {
                    Title=model.Title,
                    StartTime=model.StartTime,
                    EndTime=model.EndTime,
                    Description=model.Description

                };
                context.Appointments.Add(emp);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                TempData["error"] = "Empty field can not submit";
                return View(model);
            }
            
        }

        public IActionResult Delete(int id)
        {
            var emp=context.Appointments.SingleOrDefault(e => e.Id == id);
            context.Appointments.Remove(emp);
            context.SaveChanges();
            return RedirectToAction("Index");
        }

*/
        public IActionResult Edit()
        { 
            return View(); 
        }
    }
}
