﻿using Microsoft.Exchange.WebServices.Data;
using System.ComponentModel.DataAnnotations;

namespace User_Management.Models
{


    public class Appointment
    {


/*
        public Appointment(int id,string title, DateTime startTime, DateTime endTime,string description)
        {
            Id = id;
            Title = title;
            StartTime = startTime;
            EndTime = endTime;
            Description = description;
           
        }
*/

        [Key]
        public int Id { get; set; }
        [Required]
        public string Title { get; set; }
        [Required]
        public DateTime StartTime { get; set; }
        [Required]
        public DateTime EndTime { get; set; }
        [Required]
        public string Description { get; set; }


    }
}
