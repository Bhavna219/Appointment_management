﻿using Microsoft.AspNetCore.Mvc;
using User_Management.Data;

namespace User_Management.Controllers.Ajax
{
    public class AjaxController : Controller
    {
        private readonly ApplicationContext context;

        public AjaxController(ApplicationContext context)
        {
            this.context = context;
        }
      //  public IActionResult Index()
        //{
          //  return View();
        //}
        public JsonResult UserList()
        {
            var data=context.Appointments.ToList();
            return new JsonResult(data);
        }
    }
}
