﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Security.Claims;
using User_Management.Data;
using User_Management.Models.Account;
using User_Management.Models.ViewModel;

namespace User_Management.Controllers.Account
{
    public class AccountController : Controller
    {
        private readonly ApplicationContext context;

        public AccountController(ApplicationContext context)
        {
            this.context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(LoginSignUpViewModel model)
        {
            if (ModelState.IsValid)
            {
               var data=context.Users.Where(e=>e.Username == model.Username).SingleOrDefault();

                if (data != null)
                {
                    bool isValid=(data.Username==model.Username && data.Password==model.Password);
                    if(isValid)
                    {
                        var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, model.Username) },
                            CookieAuthenticationDefaults.AuthenticationScheme);
                        var principal=new ClaimsPrincipal(identity);
                        HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
                        HttpContext.Session.SetString("Username",model.Username);
                        return RedirectToAction("Index","Home");
                    }
                    else
                    {
                        TempData["errorPassword"] = "Invalid password";
                        return View(model);
                    }
                }
                else
                {
                    TempData["errorUserName"] = "user not found";
                    return View(model);
                }

            }
            else
            {
                return View();
            }
           
        }


        public IActionResult LogOut()
        {

            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            var storedCookies = Request.Cookies.Keys;
            foreach(var cookies in storedCookies)
            {
                Response.Cookies.Delete(cookies);
            }
        return RedirectToAction("Login","Account"); 

    }

        public IActionResult SignUp()
        {

            return View();
        }
        [HttpPost]
        public IActionResult SignUp(SignUpUserViewModel model)
        {

            if (ModelState.IsValid)
            {
                var data = new User()
                {
                    Username = model.Username,
                    Email = model.Email,
                    Mobile = model.Mobile,
                    Password = model.Password,
                    IsActive = model.IsActive,

                };
                context.Users.Add(data);
                context.SaveChanges();
                TempData["successMessage"] = "You are eligible to login,Please fill own credentials then login! ";
                return RedirectToAction("Login");
            }
            else
            {
                TempData["errorMessage"] = "Empty from can't be submitted!";

                return View(model);
            }
        }
       

    }
}



