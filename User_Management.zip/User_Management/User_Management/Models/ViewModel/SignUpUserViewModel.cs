﻿using System.ComponentModel.DataAnnotations;

namespace User_Management.Models.ViewModel
{
    public class SignUpUserViewModel
    {

        public int Id { get; set; }

        [Required(ErrorMessage ="Please enter user name")]
        public string Username { get; set; }

        [Required(ErrorMessage = "Please enter Email")]
        [RegularExpression(@"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$",ErrorMessage ="please enter valid email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter Mobile")]
        [Display (Name="Mobile Number")]
      //  [RegularExpression(" + 1234567890",ErrorMessage ="please enter valid mobile number" )]
        public long? Mobile { get; set; }

        [Required(ErrorMessage = "Please enter password")]
        public string Password { get; set; }

        [Compare("Password",ErrorMessage =("confirm password can't matched!"))] 
        [Required(ErrorMessage = "Please enter Confirm Password")]
        [Display(Name ="ConfirmPassword")]
        public string ConfirmPassword { get; set; }
        [Display (Name ="Active")]
        public bool IsActive { get; set; }
    }

}
