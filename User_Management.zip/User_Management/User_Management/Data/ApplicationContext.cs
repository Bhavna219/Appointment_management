﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Migrations.Internal;
using Microsoft.Exchange.WebServices.Data;
using User_Management.Migrations;
using User_Management.Models.Account;
using Appointment = Microsoft.Exchange.WebServices.Data.Appointment;
using IHostingEnvironment = Microsoft.AspNetCore.Hosting.IHostingEnvironment;

namespace User_Management.Data
{
    public class ApplicationContext:DbContext
    {

        private readonly string _connectionString;
        public ApplicationContext()
        {

        }

        public ApplicationContext(DbContextOptions<ApplicationContext>options) :base(options) { }
        public DbSet<User>Users { get; set; }
        public DbSet<Appointment> Appointments { get; set; }

      public ApplicationContext(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection")
                ?? throw new ArgumentNullException("ConnectionStrings");
        }
        /*
                protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
                {
                    optionsBuilder.UseSqlServer(_connectionString);
                    var builder = new ConfigurationBuilder()
                        .SetBasePath(Directory.GetCurrentDirectory())
                        .AddJsonFile("appsettings.json");

                    var config = builder.Build();

                    optionsBuilder.UseSqlServer(config.GetConnectionString("DefaultConnection"));

                }

        */


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
           base.OnConfiguring(optionsBuilder);
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json");

            var config = builder.Build();

            optionsBuilder.UseSqlServer(config.GetConnectionString("DefaultConnection"));




        }
        
    
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Appointment>().HasAlternateKey(u => u.Id);
        }


    }
}
